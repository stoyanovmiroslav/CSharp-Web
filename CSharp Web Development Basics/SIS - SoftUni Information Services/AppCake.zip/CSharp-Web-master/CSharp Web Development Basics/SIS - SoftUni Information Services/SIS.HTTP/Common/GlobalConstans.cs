﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SIS.HTTP.Common
{
    public static class GlobalConstans
    {
        public const string HttpOneProtocolFragment = "HTTP/1.1";

        public const string HttpHeaderKey = "Host";
    }
}
