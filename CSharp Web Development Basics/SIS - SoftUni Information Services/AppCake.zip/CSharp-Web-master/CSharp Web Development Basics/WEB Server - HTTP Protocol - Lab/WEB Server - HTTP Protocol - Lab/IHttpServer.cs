﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WEB_Server___HTTP_Protocol___Lab
{
    public interface IHttpServer
    {
        void Start();

        void Stop();
    }
}
