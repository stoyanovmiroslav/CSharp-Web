﻿using SIS.MvcFramework.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace IRunes
{
    public class StartUp : IMvcApplication
    {
        public void Configure()
        {
            
        }

        public void ConfigureServices()
        {
           
        }
    }
}