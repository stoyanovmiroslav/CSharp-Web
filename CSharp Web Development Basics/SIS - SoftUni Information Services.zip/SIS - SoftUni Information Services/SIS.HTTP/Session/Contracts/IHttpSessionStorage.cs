﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SIS.HTTP.Session.Contracts
{
    public interface IHttpSessionStorage
    {
        
    }
}
