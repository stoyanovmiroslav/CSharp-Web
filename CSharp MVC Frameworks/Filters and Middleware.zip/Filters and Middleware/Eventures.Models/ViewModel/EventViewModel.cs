﻿namespace Eventures.Models.ViewModel
{
    public class EventViewModel
    {
        public string Name { get; set; }

        public string Place { get; set; }

        public string Start { get; set; }

        public string End { get; set; }
    }
}